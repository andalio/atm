<?php

namespace App\Infrastructure\Api;

class RatesClient
{
    public function __construct(
        private readonly ClientInterface $client
    ) {
    }
}