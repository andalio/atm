<?php

namespace App\Domain\Commission;

use App\Domain\Commission\Exception\InvalidOperationTypeException;
use App\Domain\Operation\Operation;

class Calculator
{
    const DEPOSIT_FEE = 0.0003;
    const WITHDRAW_PRIVATE_FEE = 0.003;
    const WITHDRAW_BUSINESS_FEE = 0.005;

    private const PRIVATE_WITHDRAW_FREE_LIMIT = 1000.00;
    private const PRIVATE_WITHDRAW_FREE_OPERATIONS = 3;

    private const DEPOSIT = 'deposit';
    private const WITHDRAW = 'withdraw';

    private const PRIVATE_USER = 'private';

    private array $weeklyWithdrawals = [];

    public function calculate(Operation $operation): float
    {
        return match ($operation->getOperationType()) {
            self::DEPOSIT => $this->calculateDepositCommission($operation),
            self::WITHDRAW => $this->calculateWithdrawCommission($operation),
            default => throw new InvalidOperationTypeException(),
        };
    }

    private function calculateDepositCommission(Operation $operation): float
    {
        return $operation->getAmount() * self::DEPOSIT_FEE;
    }

    private function calculateWithdrawCommission(Operation $operation): float
    {
        if ($operation->getUserType() === self::PRIVATE_USER) {
            return $this->calculatePrivateWithdrawCommission($operation);
        }

        return $operation->getAmount() * self::WITHDRAW_BUSINESS_FEE;
    }

    private function calculatePrivateWithdrawCommission(Operation $operation): float
    {
        $weekKey = $operation->getDate()->format('oW');

        if (!isset($this->weeklyWithdrawals[$operation->getUserId()][$weekKey])) {
            $this->weeklyWithdrawals[$operation->getUserId()][$weekKey] = [
                'count' => 0,
                'total' => 0.00
            ];
        }

        $withdrawData = &$this->weeklyWithdrawals[$operation->getUserId()][$weekKey];

        if ($withdrawData['count'] < self::PRIVATE_WITHDRAW_FREE_OPERATIONS) {
            $remainingFreeLimit = self::PRIVATE_WITHDRAW_FREE_LIMIT - $withdrawData['total'];
            $withdrawData['count']++;

            if ($operation->getAmount() <= $remainingFreeLimit) {
                $withdrawData['total'] += $operation->getAmount();
                return 0.00;
            }

            $taxableAmount = $operation->getAmount() - $remainingFreeLimit;
            $withdrawData['total'] = self::PRIVATE_WITHDRAW_FREE_LIMIT;
        } else {
            $taxableAmount = $operation->getAmount();
            $withdrawData['total'] += $operation->getAmount();
        }

        return ceil($taxableAmount * self::WITHDRAW_PRIVATE_FEE * 100) / 100;
    }

}
